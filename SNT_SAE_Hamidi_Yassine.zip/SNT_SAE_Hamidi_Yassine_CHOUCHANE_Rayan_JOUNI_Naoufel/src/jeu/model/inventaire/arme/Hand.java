package jeu.model.inventaire.arme;

public class Hand extends Arme{

	public Hand() {
		super(13, "hand", 1, 500000);
	}
	
}
