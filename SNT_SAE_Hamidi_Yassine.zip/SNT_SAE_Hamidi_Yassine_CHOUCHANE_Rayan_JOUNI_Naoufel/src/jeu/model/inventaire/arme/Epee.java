package jeu.model.inventaire.arme;

public class Epee extends Arme{
		
	public Epee () {
		super(0, "epee", 10, 100);
	}

}
