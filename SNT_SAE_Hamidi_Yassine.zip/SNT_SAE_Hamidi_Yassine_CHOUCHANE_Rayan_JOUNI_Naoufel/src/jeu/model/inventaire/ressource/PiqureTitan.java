package jeu.model.inventaire.ressource;

public class PiqureTitan extends Ressource{

	public PiqureTitan() {
		super(1, 11, "Potion de titan");
	}

}
