package jeu.model.inventaire.ressource;

public class LiquideTitan extends Ressource{

	public LiquideTitan() {
		super(1, 9, "Liqude de titan");
	}

}
