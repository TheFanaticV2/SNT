package jeu.model.inventaire.ressource;

public class Bois extends Ressource{

	public Bois() {
		super(6, 5, "Bois");
	}

}
