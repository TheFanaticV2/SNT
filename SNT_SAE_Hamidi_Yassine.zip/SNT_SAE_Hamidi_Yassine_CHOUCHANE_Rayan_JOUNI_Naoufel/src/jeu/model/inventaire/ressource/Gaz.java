package jeu.model.inventaire.ressource;

public class Gaz extends Ressource{

	public Gaz() {
		super(6, 8, "Gaz");
	}
}
