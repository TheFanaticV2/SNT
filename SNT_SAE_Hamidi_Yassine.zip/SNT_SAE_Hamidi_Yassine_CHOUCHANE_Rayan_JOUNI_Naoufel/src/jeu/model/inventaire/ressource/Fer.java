package jeu.model.inventaire.ressource;



public class Fer extends Ressource{

	public Fer() {
		super(6, 7, "Fer");
	}
}
