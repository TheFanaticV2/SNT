package jeu.model.inventaire.ressource;

public class Pain extends Ressource{

	public Pain() {
		super(1, 10, "Pain");
	}

}
