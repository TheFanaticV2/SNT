package jeu.model.inventaire.ressource;

public class PotionTitan extends Ressource{

	public PotionTitan() {
		super(1, 11, "Potion de titan");
	}

}
