package jeu.model.inventaire.ressource;

public class Ciel extends Ressource{

	public Ciel() {
		super(500, 14, "Ciel");
	}
}
