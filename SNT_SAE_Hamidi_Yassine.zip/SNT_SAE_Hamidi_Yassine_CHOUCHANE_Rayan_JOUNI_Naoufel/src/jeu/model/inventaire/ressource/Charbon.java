package jeu.model.inventaire.ressource;

public class Charbon extends Ressource{

	public Charbon() {
		super(6, 6, "Charbon");
	}
}
