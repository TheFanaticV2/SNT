package jeu.model.inventaire.ressource;

public class Terre extends Ressource {

	public Terre() {
		super(6, 12, "Terre");
	}
}